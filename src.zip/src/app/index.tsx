import { setAudioModeAsync, useAudioPlayer } from "expo-audio";
import { CameraView, useCameraPermissions } from "expo-camera";
import * as Haptics from "expo-haptics";
import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Button,
  FlatList,
  Image,
  Pressable,
  Text,
  View,
} from "react-native";

export default function Index() {
  const [pokemon, setPokemon] = useState<any[]>([]);
  const [detalle, setDetalle] = useState<any>(null);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState("");

  const [permiso, pedirPermiso] = useCameraPermissions();

  const ultimoPedido = useRef(0);
  const player = useAudioPlayer(null, { downloadFirst: true });

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true });

    fetch("https://pokeapi.co/api/v2/pokemon?limit=151&offset=0")
      .then((res) => res.json())
      .then((data) => setPokemon(data.results))
      .catch(() => setError("No se pudo cargar la lista"));
  }, []);

  const vibrarFuerte = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(
      () => {}
    );

    for (let i = 0; i < 3; i++) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy).catch(() => {});
      await new Promise((listo) => setTimeout(listo, 150));
    }
  };

  const playAudio = (Audio: string) => {
    player.replace(Audio);
    player.play();

    vibrarFuerte();
  };

  const verDetalle = (url: string) => {
    ultimoPedido.current = ultimoPedido.current + 1;
    const numero = ultimoPedido.current;

    setCargando(true);
    setError("");

    fetch(url)
      .then((res) => {
        if (!res.ok) {
          throw new Error("Respuesta " + res.status);
        }
        return res.json();
      })
      .then((data) => {
        if (numero === ultimoPedido.current) {
          setDetalle(data);
        }
      })
      .catch(() => {
        if (numero === ultimoPedido.current) {
          setError("No se pudieron cargar los datos, toca el pokemon otra vez");
        }
      })
      .finally(() => {
        if (numero === ultimoPedido.current) {
          setCargando(false);
        }
      });
  };

  return (
    <View style={{ flex: 1, paddingTop: 50, backgroundColor: "#fff" }}>
      {permiso?.granted && (
        <View style={camaraCaja}>
          <CameraView style={{ flex: 1 }} facing="back" />
        </View>
      )}

      <View style={permisoFila}>
        <Text style={{ fontSize: 13, color: "#333" }}>
          Camara: {permiso?.granted ? "permiso concedido" : "sin permiso"}
        </Text>
        {!permiso?.granted && (
          <Button title="Dar permiso de camara" onPress={pedirPermiso} />
        )}
      </View>

      <FlatList
        style={{ flex: 1 }}
        data={pokemon}
        keyExtractor={(item) => item.name}
        renderItem={({ item, index }) => {
          const id = index + 1;
          const Audio = `https://raw.githubusercontent.com/PokeAPI/cries/main/cries/pokemon/latest/${id}.ogg`;
          return (
            <View style={fila}>
              <Pressable onPress={() => verDetalle(item.url)} style={filaTocable}>
                <Image
                  source={{
                    uri: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`,
                  }}
                  style={{ width: 72, height: 72 }}
                />
                <Text style={{ fontSize: 16, padding: 10, color: "#000" }}>
                  {item.name}
                </Text>
              </Pressable>
              <Button title="Audio" onPress={() => playAudio(Audio)} />
            </View>
          );
        }}
      />

      {cargando ? (
        <View style={aviso}>
          <ActivityIndicator />
          <Text style={{ fontSize: 14, color: "#888", marginTop: 8 }}>
            Cargando datos...
          </Text>
        </View>
      ) : error ? (
        <View style={panel}>
          <Text style={{ fontSize: 14, color: "#a00" }}>{error}</Text>
          <View style={{ marginTop: 10 }}>
            <Button title="Cerrar" onPress={() => setError("")} />
          </View>
        </View>
      ) : detalle ? (
        <View style={panel}>
          <Text style={titulo}>{detalle.name}</Text>
          <Text style={linea}>
            Tipos: {detalle.types?.map((t: any) => t.type.name).join(", ")}
          </Text>
          <Text style={linea}>Altura: {detalle.height / 10} m</Text>
          <Text style={linea}>Peso: {detalle.weight / 10} kg</Text>
          <Text style={linea}>
            Habilidades: {detalle.abilities?.map((a: any) => a.ability.name).join(", ")}
          </Text>
          <Text style={linea}>
            Stats: {detalle.stats?.map((s: any) => `${s.stat.name} ${s.base_stat}`).join(" · ")}
          </Text>
          <View style={{ marginTop: 10 }}>
            <Button title="Cerrar" onPress={() => setDetalle(null)} />
          </View>
        </View>
      ) : (
        <View style={aviso}>
          <Text style={{ fontSize: 15, color: "#888", textAlign: "center" }}>
            Toca un pokemon para ver sus stats :D
          </Text>
        </View>
      )}
    </View>
  );
}

const camaraCaja = {
  height: 200,
  marginHorizontal: 12,
  marginBottom: 10,
  borderRadius: 12,
  overflow: "hidden" as const,
  backgroundColor: "#000",
};

const permisoFila = {
  flexDirection: "row" as const,
  alignItems: "center" as const,
  justifyContent: "space-between" as const,
  paddingHorizontal: 12,
  paddingBottom: 8,
};

const fila = {
  flexDirection: "row" as const,
  alignItems: "center" as const,
  paddingHorizontal: 12,
  borderBottomWidth: 1,
  borderBottomColor: "#eee",
};

const filaTocable = {
  flexDirection: "row" as const,
  alignItems: "center" as const,
  flex: 1,
};

const panel = {
  backgroundColor: "#f5f5f5",
  borderWidth: 1,
  borderColor: "#ddd",
  borderRadius: 12,
  padding: 14,
  margin: 12,
};

const titulo = {
  fontSize: 18,
  fontWeight: "bold" as const,
  color: "#000",
  textTransform: "capitalize" as const,
  marginBottom: 6,
};

const linea = { fontSize: 14, color: "#333", marginBottom: 2 };

const aviso = { padding: 30, alignItems: "center" as const };
